package com.nabil.nabilmacscan

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.doAfterTextChanged
import com.nabil.nabilmacscan.databinding.ActivityMainBinding
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val client = OkHttpClient()
    private val executor = Executors.newSingleThreadExecutor()
    private val prefsName = "nabilmacscan_prefs"
    private val historyKey = "history"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Load last MAC if exists
        val prefs = getSharedPreferences(prefsName, MODE_PRIVATE)
        val last = prefs.getString("last_mac", "")
        binding.inputMac.setText(last)
        loadHistory()

        binding.btnScan.setOnClickListener {
            val mac = binding.inputMac.text.toString().trim()
            if (mac.isEmpty()) {
                Toast.makeText(this, "الرجاء إدخال MAC", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            saveLastMac(mac)
            addToHistory(mac)
            performHeuristicScan(mac)
        }

        binding.btnBulk.setOnClickListener {
            val bulk = binding.inputMac.text.toString().trim()
            if (bulk.isEmpty()) {
                Toast.makeText(this, "أدخل ماكات مفصولة بفواصل أو سطور", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val lines = bulk.split(',', '\n')
            binding.results.text = ""
            for (m in lines) {
                val mac = m.trim()
                if (mac.isNotEmpty()) {
                    addToHistory(mac)
                    performHeuristicScan(mac)
                }
            }
        }

        binding.btnClearHistory.setOnClickListener {
            prefs.edit().remove(historyKey).apply()
            binding.history.text = ""
        }
    }

    private fun saveLastMac(mac: String) {
        getSharedPreferences(prefsName, MODE_PRIVATE).edit().putString("last_mac", mac).apply()
    }

    private fun addToHistory(mac: String) {
        val prefs = getSharedPreferences(prefsName, MODE_PRIVATE)
        val history = prefs.getString(historyKey, "") ?: ""
        val items = history.split('|').filter { it.isNotBlank() }.toMutableList()
        if (items.contains(mac).not()) {
            items.add(0, mac)
        }
        // keep last 20
        val newHist = items.take(20).joinToString("|")
        prefs.edit().putString(historyKey, newHist).apply()
        loadHistory()
    }

    private fun loadHistory() {
        val prefs = getSharedPreferences(prefsName, MODE_PRIVATE)
        val history = prefs.getString(historyKey, "") ?: ""
        val items = history.split('|').filter { it.isNotBlank() }
        binding.history.text = items.joinToString("\n") { it }
    }

    private fun performHeuristicScan(mac: String) {
        // Common endpoint patterns to try
        val endpoints = listOf(
            "portal.php?mac=$mac",
            "stalker_portal/server/load.php?type=stb&action=handshake&mac=$mac",
            "c/$mac",
            "player_api.php?mac=$mac"
        )

        binding.results.append("\nفحص: $mac\n")

        executor.execute {
            for (ep in endpoints) {
                val urlVariants = listOf(
                    "http://your-server/$ep",
                    "http://your-server:8080/$ep"
                )
                for (u in urlVariants) {
                    val request = Request.Builder().url(u).get().build()
                    try {
                        val resp: Response = client.newCall(request).execute()
                        val code = resp.code
                        val body = resp.body?.string() ?: ""
                        runOnUiThread {
                            if (code in 200..299) {
                                binding.results.append("\n✅ احتمال: $u  (HTTP $code)\n")
                                // Show snippet
                                val snippet = if (body.length > 500) body.substring(0, 500) + "..." else body
                                binding.results.append(snippet + "\n")
                            } else {
                                binding.results.append("\n❌ $u  (HTTP $code)\n")
                            }
                        }
                    } catch (e: IOException) {
                        runOnUiThread {
                            binding.results.append("\nخطأ: $u -> ${e.message}\n")
                        }
                    }
                }
            }
        }
    }
}
