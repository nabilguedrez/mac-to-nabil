rootProject.name = "nabilmacscan"
include(":app")
