nabilmacscan - Android project skeleton
=======================================
This is a ready-to-open Android Studio project skeleton for the "nabilmacscan" app.
The project contains:
- A Kotlin-based Android app (single Activity) with UI for MAC input, single/bulk scan, history saved in SharedPreferences.
- Network code using OkHttp to query common IPTV endpoints heuristically (portal.php, stalker_portal, c/...).
- Adaptive launcher icon placeholder.

IMPORTANT:
- This environment cannot compile an APK for you. Open this project in Android Studio (2022.3+ recommended),
  let it download Gradle dependencies and the Android SDK components, then Build > Build Bundle(s) / APK(s).
- The project includes Gradle wrapper files for convenience, but Android Studio will usually handle the rest.

How to build (quick):
1. Download and unzip this project.
2. Open Android Studio -> Open -> select the project folder.
3. Wait for Gradle sync to complete and SDK to install if needed.
4. Run the app on an emulator or device or Build > Build Bundle(s) / APK(s).

If you want an unsigned debug APK quickly:
- In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).

Contact me here if you want me to modify UI, add server-specific authentication, or generate a compiled APK (if you provide an environment).
